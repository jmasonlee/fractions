# Fractions Package

This is a simple example package to do fractions math.
